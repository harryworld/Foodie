/*:
 # Hello! We hope you've been enjoying the session so far. Now it's time to start coding!
 
 We're going to learn about adding an iconic user interaction that is composed of dragging gesture and animations. We will learn about [SwiftUI](https://developer.apple.com/pathways/swiftui/). You can learn more about these by tapping the link.
 
 Let's start by trying our final demo.
 
 > Project Demo
 > Tap `Run My Code` on the right. Then, swipe the image to the left or right and see what happens.
 
 In the next steps, we'll start writing a few lines of code. We will break into steps. If you cannot follow, you can still go to the next page with a starting template. Are you ready to start? Let's go to the next page.
 */

import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var foods = [
        Food(image: "fruit_bowl", name: "Fruit Bowl", restaurant: "Pun Pun Market"),
        Food(image: "papaya_salad", name: "Som Tum", restaurant: "Pun Pun Market"),
        Food(image: "pencake", name: "Pencake", restaurant: "Pun Pun Market"),
        Food(image: "mango_sticky_rice", name: "Mango Sticky Rice", restaurant: "Central Plaza Airport"),
        Food(image: "pineapple_rice", name: "Pineapple Fried Rice", restaurant: "Cooking Love"),
        Food(image: "thai_sausage", name: "Northern Thai Sausage", restaurant: "Saturday Night Market"),
    ].shuffled()
    
    var body: some View {
        VStack {
            Image("Foodie")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: /*#-editable-code 150*/150/*#-end-editable-code*/)
                .shadow(radius: /*#-editable-code 8*/8/*#-end-editable-code*/)
                .offset(y: /*#-editable-code 10*/10/*#-end-editable-code*/)
            
            ZStack {
                VStack {
                    Image(systemName: "hourglass")
                        .font(.largeTitle)
                    
                    Text("/*#-editable-code Tasting more food...*/Tasting more food.../*#-end-editable-code*/")
                        .font(.title)
                }
                .fontWeight(.bold)
                .frame(maxHeight: 600)
                
                ForEach(foods) { food in
                    CardView(
                        image: food.image,
                        food: food.name,
                        restaurant: food.restaurant
                    )
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.regularMaterial)
    }
}

struct CardView: View {
    var image: String = "papaya_salad"
    var food: String = "Papaya Salad"
    var restaurant: String = "Pun Pun Market"
    
    @State var offset: CGSize = CGSize.zero
    
    var body: some View {
        ZStack(alignment: .leading) {
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 600)
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Spacer()
                
                Text(food)
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                
                Text(restaurant)
                    .font(.body)
            }
            .frame(height: 600)
            .padding()
            .padding(.bottom, 20)
            .foregroundStyle(.white)
        }
        .shadow(radius: /*#-editable-code 10*/10/*#-end-editable-code*/)
        .padding()
        .rotationEffect(Angle(degrees: Double(offset.width / 10)))
        .offset(offset)
        .gesture(
            DragGesture()
                .onChanged { self.offset = $0.translation }
                .onEnded {
                    if $0.translation.width < -100 {
                        self.offset = .init(width: -1000, height: 0)
                    } else if $0.translation.width > 100 {
                        self.offset = .init(width: 1000, height: 0)
                    } else {
                        self.offset = .zero
                    }
                }
        )
        .animation(.default, value: offset)
    }
}

struct Food: Identifiable {
    let id = UUID()
    var image: String
    var name: String
    var restaurant: String
}

PlaygroundPage.current.setLiveView(ContentView())
