/*:
 # Step 1: Start with the basics
 
 > Task
 > Goal: Learn how to write code.
 
 To start, we're going to learn a little bit of syntax of Swift.
 
 > Tip
 > If you get stuck, don't worry. Send a message in the chatroom and I will be here to help.
 
 First, you'll apply some changes to the existing text.
 
 > Task
 > You'll create a rectangle.
 
 Then, we can add a rectangle below the text.
 
 When you've successfully got a *basic layout*, you can go to the next page.
 */

import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        //: 1.1) Start here to customize text
        //#-editable-code
        Text("Hello World!")
            .font(.largeTitle)
            .fontWeight(.black)
        //#-end-editable-code
        
        //: 1.2) Now customize the rectangle
        //#-editable-code
        RoundedRectangle(cornerRadius: 8)
            .fill(.blue)
            .frame(width: 300, height: 300)
        //#-end-editable-code
    }
}

PlaygroundPage.current.setLiveView(ContentView())
