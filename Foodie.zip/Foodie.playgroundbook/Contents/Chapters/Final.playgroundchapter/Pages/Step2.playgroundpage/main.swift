/*:
 # Step 2: Improve the code structure
 
 > Task
 > Goal: Learn how to organize and reuse code.
 
 The code base is getting longer, let's reorganize them by splitting into another view.
 
 > Task
 > You'll extract the card view into its own structure.
 
 With organized code base, we can move the view easily.
 
 When you've successfully got a *card layout*, you can go to the next page.
 */

import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        VStack {
            Image("Foodie")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150)
                .shadow(radius: 8)
                .offset(y: 10)
            
            ZStack {
                VStack {
                    Image(systemName: "hourglass")
                        .font(.largeTitle)
                    
                    Text("Tasting more food...")
                        .font(.title)
                }
                .fontWeight(.bold)
                .frame(maxHeight: 600)
                
                //: 2.1) Extract into `CardView`
                //#-editable-code
                VStack {
                    RoundedRectangle(cornerRadius: 16)
                        .fill(.blue)
                        .frame(width: 300, height: 300)
                }
                //#-end-editable-code
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.regularMaterial)
    }
}

struct CardView: View {
    var body: some View {
        //: 2.2) Notice the view code here is the same.
        //#-editable-code
        VStack {
            RoundedRectangle(cornerRadius: 16)
                .fill(.blue)
                .frame(width: 300, height: 300)
        }
        //#-end-editable-code
    }
}


PlaygroundPage.current.setLiveView(ContentView())
