/*:
 # Step 4: Include data model
 
 > Task
 > Goal: Create more cards with a list of food names and images
 
 Now, having just one or two food choices are not fun. Let's add more food.
 
 > Task
 > You'll create an array of food choices and show them with a `for-loop`.
 
 Instead of copying the `CardView` for many times, we can display a list of food choices using a `for-loop`.
 
 # Congratulations
 
 You've finished this tutorial. Now you're capable to start your app development journey.
 */

import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    //: 4.1) Array of food choices
    //#-editable-code
    var foods = [
        Food(image: "fruit_bowl", name: "Fruit Bowl", restaurant: "Pun Pun Market"),
        Food(image: "papaya_salad", name: "Som Tum", restaurant: "Pun Pun Market"),
        Food(image: "pencake", name: "Pencake", restaurant: "Pun Pun Market"),
        Food(image: "mango_sticky_rice", name: "Mango Sticky Rice", restaurant: "Central Plaza Airport"),
        Food(image: "pineapple_rice", name: "Pineapple Fried Rice", restaurant: "Cooking Love"),
        Food(image: "thai_sausage", name: "Northern Thai Sausage", restaurant: "Saturday Night Market"),
    ].shuffled()
    //#-end-editable-code

    var body: some View {
        VStack {
            Image("Foodie")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150)
                .shadow(radius: 8)
                .offset(y: 10)
            
            ZStack {
                VStack {
                    Image(systemName: "hourglass")
                        .font(.largeTitle)
                    
                    Text("Tasting more food...")
                        .font(.title)
                }
                .fontWeight(.bold)
                .frame(maxHeight: 600)
                
                //: 4.2) Show multiple images using `for-loop`
                //#-editable-code
                CardView()
                //#-end-editable-code
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.regularMaterial)
    }
}

struct CardView: View {
    var image: String = "papaya_salad"
    var food: String = "Papaya Salad"
    var restaurant: String = "Pun Pun Market"
    
    @State var offset: CGSize = CGSize.zero
    
    var body: some View {
        ZStack(alignment: .leading) {
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 600)
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Spacer()
                
                Text(food)
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                
                Text(restaurant)
                    .font(.body)
            }
            .frame(height: 600)
            .padding()
            .padding(.bottom, 20)
            .foregroundStyle(.white)
        }
        .shadow(radius: /*#-editable-code 10*/10/*#-end-editable-code*/)
        .padding()
        .rotationEffect(Angle(degrees: Double(offset.width / 10)))
        .offset(offset)
        .gesture(
            DragGesture()
                .onChanged { self.offset = $0.translation }
                .onEnded {
                    if $0.translation.width < -100 {
                        self.offset = .init(width: -1000, height: 0)
                    } else if $0.translation.width > 100 {
                        self.offset = .init(width: 1000, height: 0)
                    } else {
                        self.offset = .zero
                    }
                }
        )
        .animation(.default, value: offset)
    }
}

struct Food: Identifiable {
    let id = UUID()
    var image: String
    var name: String
    var restaurant: String
}

PlaygroundPage.current.setLiveView(ContentView())
