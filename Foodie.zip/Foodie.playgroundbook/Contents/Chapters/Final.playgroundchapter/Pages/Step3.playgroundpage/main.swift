/*:
 # Step 3: Add image to the view, then implement Gesture
 
 > Task
 > Goal: You'll replace the rectangle with an image.
 
 To make it more enjoyable, let's change the rectangle to an image.
 
 > Task
 > Goal: We'll use a drag gesture to implement the swiping to the left and right.
 
 When you've successfully got a *drag gesture*, you can go to the next page.
 */

import SwiftUI
import PlaygroundSupport

struct CardView: View {
    var image: String = "papaya_salad"
    var food: String = "Papaya Salad"
    var restaurant: String = "Pun Pun Market"
    
    @State var offset: CGSize = CGSize.zero
    
    var body: some View {
        ZStack(alignment: .leading) {
            //: 3.1) Replace the rectangle with an image
            //#-editable-code
            RoundedRectangle(cornerRadius: 16)
                .fill(.blue)
                .frame(width: 300, height: 300)
            //#-end-editable-code
            
            VStack(alignment: .leading) {
                Spacer()
                
                Text(food)
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                
                Text(restaurant)
                    .font(.body)
            }
            .frame(height: 600)
            .padding()
            .padding(.bottom, 20)
            .foregroundStyle(.white)
        }
        .shadow(radius: 8)
        .padding()
        //: 3.2) Uncomment the lines below to add the gesture
        //#-editable-code
        /*
        .rotationEffect(Angle(degrees: Double(offset.width / 10)))
        .offset(offset)
        .gesture(
            DragGesture()
                .onChanged { self.offset = $0.translation }
                .onEnded {
                    if $0.translation.width < -100 {
                        self.offset = .init(width: -1000, height: 0)
                    } else if $0.translation.width > 100 {
                        self.offset = .init(width: 1000, height: 0)
                    } else {
                        self.offset = .zero
                    }
                }
        )
        .animation(.default, value: offset)
        */
        //#-end-editable-code
    }
}

PlaygroundPage.current.setLiveView(CardView())
